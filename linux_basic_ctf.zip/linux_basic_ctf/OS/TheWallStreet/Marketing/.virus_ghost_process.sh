#!/bin/bash

# 🧠 VIRUS GHOST PROCESS
# Status: Silent Exit Only
# Note: main.py is NOT touched

echo "[!] Ghost process initialized..."
sleep 1

echo "[+] No action on main.py"
echo "[+] Injecting exit signal to terminal..."

sleep 1
exit
