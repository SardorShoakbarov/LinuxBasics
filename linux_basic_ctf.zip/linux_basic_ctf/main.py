#!/usr/bin/env python3
"""
CTF Terminal Simulator - Error-Safe Version
A simulation of a Linux terminal for CTF challenges that never crashes
"""

import os
import math
import datetime
import readline
import stat
import re
import sys
import shlex
import tempfile
import subprocess
import json
import time
import threading
import signal
from pathlib import Path


REAL_OS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "OS")
current_directory_path = REAL_OS_PATH
PERMISSIONS_FILE = os.path.join(REAL_OS_PATH, ".permissions.json")

USER_NAME = "user"
HOST_NAME = "ctf-linux"

# Style uchun rang kodlari
COLOR_PROMPT_USER_HOST = "\033[32m"
COLOR_PROMPT_PATH = "\033[34m"
COLOR_DIR = "\033[94m"
COLOR_FILE = "\033[0m"
COLOR_EXEC = "\033[32m"
COLOR_RESET = "\033[0m"
COLOR_CYAN = "\033[36m"

COLOR_HACKING_RED = "\033[31m"
COLOR_HACKING_GREEN = "\033[32m"
COLOR_HACKING_YELLOW = "\033[33m"
COLOR_HACKING_CYAN = "\033[36m"
COLOR_HACKING_MAGENTA = "\033[35m"
COLOR_HACKING_BOLD = "\033[1m"
COLOR_ERROR = "\033[91m"
COLOR_WARNING = "\033[93m"

# --- Global o'zgaruvchilar ---
COMMAND_HISTORY = []
ALIASES = {
    'll': 'ls -la',
    'la': 'ls -a',
    'l': 'ls -l'
}

# Watch command globals
WATCH_ACTIVE = False
WATCH_THREAD = None

# Permissions storage
FILE_PERMISSIONS = {}
FILE_OWNERSHIP = {}

# --- Xato boshqaruv funksiyalari ---
def safe_execute(func, *args, **kwargs):
    """Xavfsiz bajarish wrapper - hech qachon dasturni to'xtatmaydi"""
    try:
        return func(*args, **kwargs)
    except KeyboardInterrupt:
        print(f"\n{COLOR_ERROR}^C{COLOR_RESET}")
        return None
    except EOFError:
        print(f"\n{COLOR_ERROR}Unexpected end of input{COLOR_RESET}")
        return None
    except SystemExit:
        print(f"{COLOR_ERROR}System exit prevented{COLOR_RESET}")
        return None
    except Exception as e:
        print(f"{COLOR_ERROR}Unexpected error: {str(e)}{COLOR_RESET}")
        return None

def print_error(command, message):
    """Xato xabarini chiqarish"""
    print(f"{COLOR_ERROR}{command}: {message}{COLOR_RESET}")

def print_warning(command, message):
    """Ogohlantirish xabarini chiqarish"""
    print(f"{COLOR_WARNING}{command}: {message}{COLOR_RESET}")

def print_command_not_found(command):
    """Command topilmadi xabari"""
    print(f"{COLOR_ERROR}bash: {command}: command not found{COLOR_RESET}")

def print_invalid_option(command, option):
    """Noto'g'ri opsiya xabari"""
    print(f"{COLOR_ERROR}{command}: invalid option -- '{option}'{COLOR_RESET}")
    print(f"Try '{command} --help' for more information.")

def print_missing_operand(command):
    """Operand yetishmaydi xabari"""
    print(f"{COLOR_ERROR}{command}: missing operand{COLOR_RESET}")
    print(f"Try '{command} --help' for more information.")

def print_syntax_error(command, details=""):
    """Sintaksis xatosi xabari"""
    if details:
        print(f"{COLOR_ERROR}{command}: syntax error: {details}{COLOR_RESET}")
    else:
        print(f"{COLOR_ERROR}{command}: syntax error{COLOR_RESET}")

def validate_arguments(command, args, min_args=0, max_args=None):
    """Argumentlarni tekshirish"""
    if not args and min_args > 0:
        print_missing_operand(command)
        return False
    
    if args:
        try:
            arg_list = shlex.split(args)
        except ValueError as e:
            print_syntax_error(command, str(e))
            return False
        
        if len(arg_list) < min_args:
            print_missing_operand(command)
            return False
        
        if max_args and len(arg_list) > max_args:
            print_error(command, "too many arguments")
            return False
    
    return True

def parse_arguments(args_str):
    """Argumentlarni xavfsiz parse qilish"""
    if not args_str:
        return []
    
    try:
        return shlex.split(args_str)
    except ValueError as e:
        print_syntax_error("parse", str(e))
        return None

def safe_path_resolve(path, operation=""):
    """Xavfsiz yo'l hal qilish"""
    try:
        if not path:
            return current_directory_path
        
        if path.startswith("/"):
            if path.lower().startswith("/os"):
                relative_part = path[len("/OS"):] if path.startswith("/OS") else path[len("/os"):]
                if not relative_part:
                    return REAL_OS_PATH
                return os.path.abspath(os.path.join(REAL_OS_PATH, relative_part.lstrip('/')))
            else:
                return path
        else:
            return os.path.abspath(os.path.join(current_directory_path, path))
    except Exception as e:
        if operation:
            print_error(operation, f"invalid path '{path}': {e}")
        return None

# --- Permission system ---
def safe_load_permissions():
    """Ruxsatlarni xavfsiz yuklash"""
    global FILE_PERMISSIONS, FILE_OWNERSHIP
    try:
        if os.path.exists(PERMISSIONS_FILE):
            with open(PERMISSIONS_FILE, 'r') as f:
                data = json.load(f)
                FILE_PERMISSIONS = data.get('permissions', {})
                FILE_OWNERSHIP = data.get('ownership', {})
    except Exception:
        FILE_PERMISSIONS = {}
        FILE_OWNERSHIP = {}

def safe_save_permissions():
    """Ruxsatlarni xavfsiz saqlash"""
    try:
        data = {
            'permissions': FILE_PERMISSIONS,
            'ownership': FILE_OWNERSHIP
        }
        with open(PERMISSIONS_FILE, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass  # Saqlashda xato bo'lsa ham dastur davom etsin

def get_file_permissions(file_path):
    """Fayl ruxsatlarini olish"""
    try:
        if file_path in FILE_PERMISSIONS:
            return FILE_PERMISSIONS[file_path]
        
        # Default permissions
        if os.path.isdir(file_path):
            perms = 0o755
        else:
            perms = 0o644
        
        FILE_PERMISSIONS[file_path] = perms
        safe_save_permissions()
        return perms
    except Exception:
        return 0o644

def set_file_permissions(file_path, permissions):
    """Fayl ruxsatlarini o'rnatish"""
    try:
        FILE_PERMISSIONS[file_path] = permissions
        safe_save_permissions()
        return True
    except Exception:
        return False

def get_file_ownership(file_path):
    """Fayl egachiligini olish"""
    try:
        if file_path in FILE_OWNERSHIP:
            return FILE_OWNERSHIP[file_path]
        
        # Default ownership
        ownership = {'user': USER_NAME, 'group': USER_NAME}
        FILE_OWNERSHIP[file_path] = ownership
        safe_save_permissions()
        return ownership
    except Exception:
        return {'user': USER_NAME, 'group': USER_NAME}

def set_file_ownership(file_path, user=None, group=None):
    """Fayl egachiligini o'rnatish"""
    try:
        if file_path not in FILE_OWNERSHIP:
            FILE_OWNERSHIP[file_path] = {'user': USER_NAME, 'group': USER_NAME}
        
        if user:
            FILE_OWNERSHIP[file_path]['user'] = user
        if group:
            FILE_OWNERSHIP[file_path]['group'] = group
        
        safe_save_permissions()
        return True
    except Exception:
        return False

# --- Yordamchi funksiyalar ---
def get_display_path_string():
    """Path displayni olish"""
    try:
        if current_directory_path == REAL_OS_PATH:
            return "~"
        relative_path = os.path.relpath(current_directory_path, REAL_OS_PATH)
        if relative_path == ".":
            return "~"
        return f"~/{relative_path}"
    except Exception:
        return "~"

def get_permissions_string(file_path):
    """Ruxsatlar stringini olish"""
    try:
        permissions = get_file_permissions(file_path)
        perms = ['-'] * 10
        
        if os.path.isdir(file_path):
            perms[0] = 'd'
        elif os.path.islink(file_path):
            perms[0] = 'l'

        # User permissions
        perms[1] = 'r' if (permissions & 0o400) else '-'
        perms[2] = 'w' if (permissions & 0o200) else '-'
        perms[3] = 'x' if (permissions & 0o100) else '-'

        # Group permissions
        perms[4] = 'r' if (permissions & 0o040) else '-'
        perms[5] = 'w' if (permissions & 0o020) else '-'
        perms[6] = 'x' if (permissions & 0o010) else '-'

        # Other permissions
        perms[7] = 'r' if (permissions & 0o004) else '-'
        perms[8] = 'w' if (permissions & 0o002) else '-'
        perms[9] = 'x' if (permissions & 0o001) else '-'

        return "".join(perms)
    except Exception:
        return "----------"

def safe_file_check(filename, operation_name):
    """Xavfsiz fayl tekshiruvi"""
    try:
        if not filename:
            print_missing_operand(operation_name)
            return None
        
        resolved_file = safe_path_resolve(filename, operation_name)
        if resolved_file is None:
            return None
        
        if not resolved_file.startswith(REAL_OS_PATH):
            print_error(operation_name, f"'{filename}': Permission denied")
            return None
        
        if not os.path.exists(resolved_file):
            print_error(operation_name, f"'{filename}': No such file or directory")
            return None
        
        return resolved_file
    except Exception as e:
        print_error(operation_name, f"'{filename}': {str(e)}")
        return None

# --- Buyruq funksiyalari ---
def ls_command(args_str=None):
    """ls buyrug'i - xavfsiz versiya"""
    try:
        show_hidden = False
        long_format = False
        
        if args_str:
            args = parse_arguments(args_str)
            if args is None:
                return
        else:
            args = []

        # Argumentlarni parse qilish
        parsed_args = []
        for arg in args:
            if arg.startswith("-"):
                if arg == "--help":
                    print("Usage: ls [OPTION]... [FILE]...")
                    print("List directory contents")
                    print("  -a, --all             show hidden files")
                    print("  -l                    use long listing format")
                    print("      --help            display this help")
                    return
                
                for char in arg[1:]:
                    if char == 'a':
                        show_hidden = True
                    elif char == 'l':
                        long_format = True
                    else:
                        print_invalid_option("ls", char)
                        return
            else:
                parsed_args.append(arg)

        # Target path aniqlash
        if not parsed_args:
            target_path = current_directory_path
        elif len(parsed_args) == 1:
            target_path = safe_path_resolve(parsed_args[0], "ls")
            if target_path is None:
                return
        else:
            # Bir nechta path
            for path_arg in parsed_args:
                resolved_path = safe_path_resolve(path_arg, "ls")
                if resolved_path is None:
                    continue
                
                if not resolved_path.startswith(REAL_OS_PATH):
                    print_error("ls", f"'{path_arg}': Permission denied")
                    continue
                
                if not os.path.exists(resolved_path):
                    print_error("ls", f"'{path_arg}': No such file or directory")
                    continue
                
                print(f"\n{path_arg}:")
                safe_execute(_ls_display_items, resolved_path, show_hidden, long_format)
            return

        # Yagona path uchun
        if not target_path.startswith(REAL_OS_PATH):
            print_error("ls", "Permission denied")
            return

        if not os.path.exists(target_path):
            print_error("ls", "No such file or directory")
            return
                
        if os.path.isfile(target_path):
            safe_execute(_display_single_file_ls, target_path, long_format)
        elif os.path.isdir(target_path):
            safe_execute(_ls_display_items, target_path, show_hidden, long_format)
            
    except Exception as e:
        print_error("ls", f"unexpected error: {str(e)}")

def _ls_display_items(directory_path, show_hidden, long_format):
    """ls natijalari ko'rsatish"""
    try:
        items = []
        all_items = os.listdir(directory_path)
                        
        for item_name in sorted(all_items):
            if not show_hidden and item_name.startswith('.'):
                continue
                                
            full_item_path = os.path.join(directory_path, item_name)
                                
            display_name = item_name
            if os.path.isdir(full_item_path):
                display_name = f"{COLOR_DIR}{item_name}/{COLOR_RESET}"
            elif os.path.islink(full_item_path):
                try:
                    target_link = os.readlink(full_item_path)
                    display_name = f"{COLOR_CYAN}{item_name}{COLOR_RESET} -> {target_link}"
                except OSError:
                    display_name = f"{COLOR_CYAN}{item_name}{COLOR_RESET}"
            elif os.path.isfile(full_item_path):
                perms = get_file_permissions(full_item_path)
                if perms & 0o100:  # Executable
                    display_name = f"{COLOR_EXEC}{item_name}{COLOR_RESET}"
                else:
                    display_name = f"{COLOR_FILE}{item_name}{COLOR_RESET}"
            else:
                display_name = f"{COLOR_FILE}{item_name}{COLOR_RESET}"
                                
            if long_format:
                try:
                    stat_info = os.lstat(full_item_path) if os.path.islink(full_item_path) else os.stat(full_item_path)
                    perms_str = get_permissions_string(full_item_path)
                    nlink = stat_info.st_nlink
                    ownership = get_file_ownership(full_item_path)
                    owner_name = ownership['user']
                    group_name = ownership['group']
                    size = stat_info.st_size
                    mod_time = datetime.datetime.fromtimestamp(stat_info.st_mtime).strftime('%b %d %H:%M')
                                                
                    long_entry = f"{perms_str} {nlink:2} {owner_name:8} {group_name:8} {size:8} {mod_time} {display_name}"
                    items.append(long_entry)
                except OSError:
                    items.append(f"????????? {display_name} (Permission denied)")
            else:
                items.append(display_name)
                        
        # Chiqarish
        if not items:
            return

        if long_format:
            for item in items:
                print(item)
        else:
            # Ustunlar formatida
            COLUMNS = 3
            max_len = max(len(re.sub(r'\x1b\[[0-9;]*m', '', item.split(" -> ")[0])) for item in items)
            column_width = max_len + 4
            rows_per_column = math.ceil(len(items) / COLUMNS)
                        
            for r in range(rows_per_column):
                line = []
                for c in range(COLUMNS):
                    idx = r + c * rows_per_column
                    if idx < len(items):
                        item_display = items[idx]
                        clean_item = re.sub(r'\x1b\[[0-9;]*m', '', item_display.split(" -> ")[0])
                        padding_needed = column_width - len(clean_item)
                        line.append(item_display + " " * padding_needed)
                print("".join(line))
                
    except PermissionError:
        print_error("ls", "Permission denied")
    except Exception as e:
        print_error("ls", f"unexpected error: {str(e)}")

def _display_single_file_ls(file_path, long_format):
    """Bitta fayl uchun ls"""
    try:
        item_name = os.path.basename(file_path)
        perms = get_file_permissions(file_path)
        if perms & 0o100:  # Executable
            display_name = f"{COLOR_EXEC}{item_name}{COLOR_RESET}"
        else:
            display_name = f"{COLOR_FILE}{item_name}{COLOR_RESET}"

        if long_format:
            try:
                stat_info = os.stat(file_path)
                perms_str = get_permissions_string(file_path)
                nlink = stat_info.st_nlink
                ownership = get_file_ownership(file_path)
                owner_name = ownership['user']
                group_name = ownership['group']
                size = stat_info.st_size
                mod_time = datetime.datetime.fromtimestamp(stat_info.st_mtime).strftime('%b %d %H:%M')
                print(f"{perms_str} {nlink:2} {owner_name:8} {group_name:8} {size:8} {mod_time} {display_name}")
            except OSError:
                print_error("ls", "Permission denied")
        else:
            print(display_name)
    except Exception as e:
        print_error("ls", f"unexpected error: {str(e)}")

def cd_command(target_path):
    """cd buyrug'i"""
    global current_directory_path
    try:
        if not target_path or target_path == "~":
            current_directory_path = REAL_OS_PATH
            return
        
        resolved_target = safe_path_resolve(target_path, "cd")
        if resolved_target is None:
            return
        
        if not resolved_target.startswith(REAL_OS_PATH):
            if os.path.exists(resolved_target):
                print_error("cd", f"'{target_path}': Permission denied")
            else:
                print_error("cd", f"'{target_path}': No such file or directory")
            return

        if not os.path.exists(resolved_target):
            print_error("cd", f"'{target_path}': No such file or directory")
            return
        
        if os.path.isdir(resolved_target):
            current_directory_path = resolved_target
        else:
            print_error("cd", f"'{target_path}': Not a directory")
            
    except Exception as e:
        print_error("cd", f"unexpected error: {str(e)}")

def cat_command(filename):
    """cat buyrug'i"""
    try:
        if not validate_arguments("cat", filename, min_args=1):
            return
        
        resolved_file = safe_file_check(filename, "cat")
        if resolved_file is None:
            return
        
        if os.path.isdir(resolved_file):
            print_error("cat", f"'{filename}': Is a directory")
            return
        
        with open(resolved_file, 'r', encoding='utf-8', errors='ignore') as f:
            print(f.read(), end='')
    except PermissionError:
        print_error("cat", f"'{filename}': Permission denied")
    except Exception as e:
        print_error("cat", f"'{filename}': {str(e)}")

def chmod_command(args_str):
    """chmod buyrug'i - to'liq ishlaydigan versiya"""
    try:
        if not validate_arguments("chmod", args_str, min_args=2):
            return
        
        args = parse_arguments(args_str)
        if args is None:
            return
        
        recursive = False
        verbose = False
        reference_file = None
        mode = None
        files = []
        
        i = 0
        while i < len(args):
            arg = args[i]
            
            if arg == "-R" or arg == "--recursive":
                recursive = True
                i += 1
            elif arg == "-v" or arg == "--verbose":
                verbose = True
                i += 1
            elif arg.startswith("--reference="):
                reference_file = arg[12:]
                i += 1
            elif arg == "--reference":
                if i + 1 < len(args):
                    reference_file = args[i + 1]
                    i += 2
                else:
                    print_error("chmod", "option '--reference' requires an argument")
                    return
            elif arg == "--help":
                print("Usage: chmod [OPTION]... MODE[,MODE]... FILE...")
                print("Change file permissions")
                print("  -R, --recursive       change files and directories recursively")
                print("  -v, --verbose         output a diagnostic for every file processed")
                print("      --reference=RFILE use RFILE's mode instead of MODE values")
                print("      --help            display this help and exit")
                return
            elif arg.startswith("-"):
                print_invalid_option("chmod", arg[1:])
                return
            elif mode is None:
                mode = arg
                i += 1
            else:
                files.append(arg)
                i += 1
        
        if not files:
            print_missing_operand("chmod")
            return
        
        if reference_file:
            ref_path = safe_file_check(reference_file, "chmod")
            if ref_path is None:
                return
            reference_mode = get_file_permissions(ref_path)
        
        def apply_chmod(file_path, file_name):
            try:
                if reference_file:
                    new_mode = reference_mode
                else:
                    current_mode = get_file_permissions(file_path)
                    new_mode = parse_chmod_mode(mode, current_mode)
                    if new_mode is None:
                        return
                
                if set_file_permissions(file_path, new_mode):
                    if verbose:
                        print(f"mode of '{file_name}' changed to {oct(new_mode)[2:]}")
                else:
                    print_error("chmod", f"changing permissions of '{file_name}': Operation not permitted")
            except Exception as e:
                print_error("chmod", f"changing permissions of '{file_name}': {str(e)}")
        
        for file_pattern in files:
            resolved_file = safe_path_resolve(file_pattern, "chmod")
            if resolved_file is None:
                continue
            
            if not resolved_file.startswith(REAL_OS_PATH):
                print_error("chmod", f"'{file_pattern}': Permission denied")
                continue
            
            if not os.path.exists(resolved_file):
                print_error("chmod", f"'{file_pattern}': No such file or directory")
                continue
            
            if recursive and os.path.isdir(resolved_file):
                for root, dirs, files_in_dir in os.walk(resolved_file):
                    apply_chmod(root, os.path.relpath(root, REAL_OS_PATH))
                    for file_name in files_in_dir:
                        file_path = os.path.join(root, file_name)
                        apply_chmod(file_path, os.path.relpath(file_path, REAL_OS_PATH))
            else:
                apply_chmod(resolved_file, file_pattern)
    
    except Exception as e:
        print_error("chmod", f"unexpected error: {str(e)}")

def parse_chmod_mode(mode_str, current_mode):
    """chmod mode stringini parse qilish"""
    try:
        # Octal format
        if mode_str.isdigit():
            return int(mode_str, 8)
        
        # Symbolic format
        new_mode = current_mode
        
        # Mode stringni qismlarga bo'lish
        modes = mode_str.split(',')
        
        for mode_part in modes:
            mode_part = mode_part.strip()
            if not mode_part:
                continue
            
            # Parse who (u, g, o, a)
            who = ""
            op = ""
            perms = ""
            
            i = 0
            while i < len(mode_part) and mode_part[i] in 'ugoa':
                who += mode_part[i]
                i += 1
            
            if i < len(mode_part) and mode_part[i] in '+-=':
                op = mode_part[i]
                i += 1
            
            while i < len(mode_part) and mode_part[i] in 'rwxXstugo':
                perms += mode_part[i]
                i += 1
            
            if not who:
                who = "a"  # Default to all
            
            if not op:
                print_error("chmod", f"invalid mode: '{mode_part}'")
                return None
            
            # Calculate permission bits
            perm_bits = 0
            if 'r' in perms:
                perm_bits |= 0o444
            if 'w' in perms:
                perm_bits |= 0o222
            if 'x' in perms:
                perm_bits |= 0o111
            
            # Apply to specific users
            user_bits = 0
            group_bits = 0
            other_bits = 0
            
            if 'u' in who or 'a' in who:
                user_bits = (perm_bits >> 6) & 0o7
            if 'g' in who or 'a' in who:
                group_bits = (perm_bits >> 3) & 0o7
            if 'o' in who or 'a' in who:
                other_bits = perm_bits & 0o7
            
            final_bits = (user_bits << 6) | (group_bits << 3) | other_bits
            
            # Apply operation
            if op == '=':
                # Clear and set
                if 'u' in who or 'a' in who:
                    new_mode &= ~0o700
                    new_mode |= (user_bits << 6)
                if 'g' in who or 'a' in who:
                    new_mode &= ~0o070
                    new_mode |= (group_bits << 3)
                if 'o' in who or 'a' in who:
                    new_mode &= ~0o007
                    new_mode |= other_bits
            elif op == '+':
                new_mode |= final_bits
            elif op == '-':
                new_mode &= ~final_bits
        
        return new_mode
    except Exception as e:
        print_error("chmod", f"invalid mode: '{mode_str}': {str(e)}")
        return None

def chown_command(args_str):
    """chown buyrug'i - to'liq ishlaydigan versiya"""
    try:
        if not validate_arguments("chown", args_str, min_args=2):
            return
        
        args = parse_arguments(args_str)
        if args is None:
            return
        
        recursive = False
        verbose = False
        reference_file = None
        owner_spec = None
        files = []
        
        i = 0
        while i < len(args):
            arg = args[i]
            
            if arg == "-R" or arg == "--recursive":
                recursive = True
                i += 1
            elif arg == "-v" or arg == "--verbose":
                verbose = True
                i += 1
            elif arg.startswith("--reference="):
                reference_file = arg[12:]
                i += 1
            elif arg == "--reference":
                if i + 1 < len(args):
                    reference_file = args[i + 1]
                    i += 2
                else:
                    print_error("chown", "option '--reference' requires an argument")
                    return
            elif arg == "--help":
                print("Usage: chown [OPTION]... [OWNER][:[GROUP]] FILE...")
                print("Change file owner and group")
                print("  -R, --recursive       operate on files and directories recursively")
                print("  -v, --verbose         output a diagnostic for every file processed")
                print("      --reference=RFILE use RFILE's owner and group rather than specifying OWNER:GROUP")
                print("      --help            display this help and exit")
                return
            elif arg.startswith("-"):
                print_invalid_option("chown", arg[1:])
                return
            elif owner_spec is None:
                owner_spec = arg
                i += 1
            else:
                files.append(arg)
                i += 1
        
        if not files:
            print_missing_operand("chown")
            return
        
        if reference_file:
            ref_path = safe_file_check(reference_file, "chown")
            if ref_path is None:
                return
            reference_ownership = get_file_ownership(ref_path)
            new_user = reference_ownership['user']
            new_group = reference_ownership['group']
        else:
            new_user, new_group = parse_chown_spec(owner_spec)
            if new_user is None and new_group is None:
                return
        
        def apply_chown(file_path, file_name):
            try:
                old_ownership = get_file_ownership(file_path)
                
                user_to_set = new_user if new_user is not None else old_ownership['user']
                group_to_set = new_group if new_group is not None else old_ownership['group']
                
                if set_file_ownership(file_path, user_to_set, group_to_set):
                    if verbose:
                        print(f"changed ownership of '{file_name}' to {user_to_set}:{group_to_set}")
                else:
                    print_error("chown", f"changing ownership of '{file_name}': Operation not permitted")
            except Exception as e:
                print_error("chown", f"changing ownership of '{file_name}': {str(e)}")
        
        for file_pattern in files:
            resolved_file = safe_path_resolve(file_pattern, "chown")
            if resolved_file is None:
                continue
            
            if not resolved_file.startswith(REAL_OS_PATH):
                print_error("chown", f"'{file_pattern}': Permission denied")
                continue
            
            if not os.path.exists(resolved_file):
                print_error("chown", f"'{file_pattern}': No such file or directory")
                continue
            
            if recursive and os.path.isdir(resolved_file):
                for root, dirs, files_in_dir in os.walk(resolved_file):
                    apply_chown(root, os.path.relpath(root, REAL_OS_PATH))
                    for file_name in files_in_dir:
                        file_path = os.path.join(root, file_name)
                        apply_chown(file_path, os.path.relpath(file_path, REAL_OS_PATH))
            else:
                apply_chown(resolved_file, file_pattern)
    
    except Exception as e:
        print_error("chown", f"unexpected error: {str(e)}")

def parse_chown_spec(spec):
    """chown specification ni parse qilish"""
    try:
        if ':' in spec:
            user, group = spec.split(':', 1)
            return user if user else None, group if group else None
        else:
            return spec, None
    except Exception as e:
        print_error("chown", f"invalid user:group specification: '{spec}': {str(e)}")
        return None, None

def watch_command(args_str):
    """watch buyrug'i - to'liq ishlaydigan versiya"""
    global WATCH_ACTIVE, WATCH_THREAD
    
    try:
        if not validate_arguments("watch", args_str, min_args=1):
            return
        
        args = parse_arguments(args_str)
        if args is None:
            return
        
        interval = 2.0
        precise = False
        no_title = False
        differences = False
        command_to_watch = []
        
        i = 0
        while i < len(args):
            arg = args[i]
            
            if arg == "-n" or arg == "--interval":
                if i + 1 < len(args):
                    try:
                        interval = float(args[i + 1])
                        if interval <= 0:
                            print_error("watch", "invalid interval")
                            return
                        i += 2
                    except ValueError:
                        print_error("watch", f"invalid interval: '{args[i + 1]}'")
                        return
                else:
                    print_error("watch", "option requires an argument -- 'n'")
                    return
            elif arg.startswith("-n"):
                try:
                    interval = float(arg[2:])
                    if interval <= 0:
                        print_error("watch", "invalid interval")
                        return
                    i += 1
                except ValueError:
                    print_error("watch", f"invalid interval: '{arg[2:]}'")
                    return
            elif arg == "-p" or arg == "--precise":
                precise = True
                i += 1
            elif arg == "-t" or arg == "--no-title":
                no_title = True
                i += 1
            elif arg == "-d" or arg == "--differences":
                differences = True
                i += 1
            elif arg == "--help":
                print("Usage: watch [OPTION]... COMMAND")
                print("Execute a program periodically, showing output fullscreen")
                print("  -n, --interval <secs>  seconds to wait between updates")
                print("  -p, --precise          precise timekeeping")
                print("  -t, --no-title         turn off header")
                print("  -d, --differences      highlight changes between updates")
                print("      --help             display this help and exit")
                return
            elif arg.startswith("-"):
                print_invalid_option("watch", arg[1:])
                return
            else:
                command_to_watch = args[i:]
                break
        
        if not command_to_watch:
            print_missing_operand("watch")
            return
        
        # Join command parts
        full_command = " ".join(command_to_watch)
        
        print(f"Starting watch: {full_command}")
        print("Press Ctrl+C to stop...")
        
        WATCH_ACTIVE = True
        previous_output = ""
        
        try:
            while WATCH_ACTIVE:
                # Clear screen
                os.system('cls' if os.name == 'nt' else 'clear')
                
                # Show header
                if not no_title:
                    current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    print(f"Every {interval}s: {full_command}")
                    print(f"Time: {current_time}")
                    print()
                
                # Execute command
                try:
                    # Parse and execute the command
                    cmd_parts = full_command.split(" ", 1)
                    cmd = cmd_parts[0]
                    cmd_args = cmd_parts[1] if len(cmd_parts) > 1 else ""
                    
                    # Capture output
                    import io
                    from contextlib import redirect_stdout
                    
                    output_capture = io.StringIO()
                    with redirect_stdout(output_capture):
                        safe_execute(execute_command, cmd, cmd_args, from_source=True)
                    
                    current_output = output_capture.getvalue()
                    
                    if differences and previous_output:
                        # Highlight differences (simple implementation)
                        print(current_output)
                        if current_output != previous_output:
                            print(f"{COLOR_HACKING_YELLOW}[Output changed]{COLOR_RESET}")
                    else:
                        print(current_output)
                    
                    previous_output = current_output
                    
                except Exception as e:
                    print_error("watch", f"command execution failed: {str(e)}")
                
                # Wait for interval
                if precise:
                    time.sleep(interval)
                else:
                    time.sleep(interval)
                
        except KeyboardInterrupt:
            WATCH_ACTIVE = False
            print(f"\n{COLOR_HACKING_GREEN}Watch stopped.{COLOR_RESET}")
    
    except Exception as e:
        print_error("watch", f"unexpected error: {str(e)}")
        WATCH_ACTIVE = False

# Command mapping with error handling
def safe_command_wrapper(command_func):
    """Buyruq funksiyasini xavfsiz wrapper bilan o'rash"""
    def wrapper(*args, **kwargs):
        return safe_execute(command_func, *args, **kwargs)
    return wrapper

# Qolgan buyruqlar...
def mkdir_command(args_str):
    """mkdir buyrug'i"""
    try:
        if not validate_arguments("mkdir", args_str, min_args=1):
            return
        
        dir_names = parse_arguments(args_str)
        if dir_names is None:
            return
        
        for dirname in dir_names:
            if not dirname:
                continue
            
            full_path = os.path.join(current_directory_path, dirname)
            if not full_path.startswith(REAL_OS_PATH):
                print_error("mkdir", f"'{dirname}': Permission denied")
                continue
            
            if os.path.exists(full_path):
                print_error("mkdir", f"'{dirname}': File exists")
            else:
                try:
                    os.mkdir(full_path)
                except PermissionError:
                    print_error("mkdir", f"'{dirname}': Permission denied")
                except OSError as e:
                    print_error("mkdir", f"'{dirname}': {str(e)}")
    except Exception as e:
        print_error("mkdir", f"unexpected error: {str(e)}")

def touch_command(args_str):
    """touch buyrug'i"""
    try:
        if not validate_arguments("touch", args_str, min_args=1):
            return
        
        filename = args_str.strip()
        full_path = os.path.join(current_directory_path, filename)
        
        if not full_path.startswith(REAL_OS_PATH):
            print_error("touch", f"'{filename}': Permission denied")
            return
        
        if os.path.isdir(full_path):
            print_error("touch", f"'{filename}': Is a directory")
        else:
            try:
                with open(full_path, 'a', encoding='utf-8'):
                    pass
                os.utime(full_path, None)
            except PermissionError:
                print_error("touch", f"'{filename}': Permission denied")
            except Exception as e:
                print_error("touch", f"'{filename}': {str(e)}")
    except Exception as e:
        print_error("touch", f"unexpected error: {str(e)}")

def echo_command(args_str):
    """echo buyrug'i"""
    try:
        if not args_str:
            print()
            return
        
        # Redirection check
        if '>' in args_str:
            parts = args_str.split('>', 1)
            text_to_write = parts[0].strip()
            redirect_target = parts[1].strip()
            
            append_mode = False
            if redirect_target.startswith('>'):
                append_mode = True
                redirect_target = redirect_target[1:].strip()
            
            # Remove quotes from text
            if text_to_write.startswith('"') and text_to_write.endswith('"'):
                text_to_write = text_to_write[1:-1]
            elif text_to_write.startswith("'") and text_to_write.endswith("'"):
                text_to_write = text_to_write[1:-1]
            
            resolved_file = safe_path_resolve(redirect_target, "echo")
            if resolved_file is None:
                return
            
            if not resolved_file.startswith(REAL_OS_PATH):
                print_error("echo", f"'{redirect_target}': Permission denied")
                return
            
            try:
                mode = 'a' if append_mode else 'w'
                with open(resolved_file, mode, encoding='utf-8') as f:
                    f.write(text_to_write + '\n')
            except PermissionError:
                print_error("echo", f"'{redirect_target}': Permission denied")
            except Exception as e:
                print_error("echo", f"{str(e)}")
        else:
            # Regular echo
            text = args_str
            # Remove quotes if present
            if text.startswith('"') and text.endswith('"'):
                text = text[1:-1]
            elif text.startswith("'") and text.endswith("'"):
                text = text[1:-1]
            print(text)
    except Exception as e:
        print_error("echo", f"unexpected error: {str(e)}")

def grep_command(args_str):
    """grep buyrug'i"""
    try:
        if not validate_arguments("grep", args_str, min_args=2):
            return
        
        args = parse_arguments(args_str)
        if args is None:
            return
        
        if len(args) < 2:
            print_missing_operand("grep")
            return
        
        pattern = args[0]
        filename = args[1]
        
        resolved_file = safe_file_check(filename, "grep")
        if resolved_file is None:
            return

        try:
            with open(resolved_file, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    if pattern in line:
                        print(line.rstrip('\n'))
        except PermissionError:
            print_error("grep", f"'{filename}': Permission denied")
        except Exception as e:
            print_error("grep", f"'{filename}': {str(e)}")
    except Exception as e:
        print_error("grep", f"unexpected error: {str(e)}")

def awk_command(args_str):
    """AWK buyrug'i - soddalashtirilgan versiya"""
    try:
        if not validate_arguments("awk", args_str, min_args=2):
            return
        
        args = parse_arguments(args_str)
        if args is None:
            return
        
        if len(args) < 2:
            print_missing_operand("awk")
            return
        
        # Field separator va boshqa opsiyalarni parse qilish
        field_separator = None
        script = None
        filename = None
        
        i = 0
        while i < len(args):
            if args[i] == '-F':
                if i + 1 < len(args):
                    field_separator = args[i + 1]
                    i += 2
                else:
                    print_error("awk", "option requires an argument -- 'F'")
                    return
            elif args[i].startswith('-F'):
                # -F',' yoki -F, formatida
                field_separator = args[i][2:]
                i += 1
            elif script is None:
                script = args[i]
                i += 1
            elif filename is None:
                filename = args[i]
                i += 1
            else:
                i += 1
        
        if script is None or filename is None:
            print_error("awk", "missing script or filename")
            return
        
        if field_separator is None:
            field_separator = r'\s+'  # Default whitespace
        elif field_separator.startswith("'") and field_separator.endswith("'"):
            field_separator = field_separator[1:-1]  # Remove quotes
        elif field_separator.startswith('"') and field_separator.endswith('"'):
            field_separator = field_separator[1:-1]  # Remove quotes
        
        resolved_file = safe_file_check(filename, "awk")
        if resolved_file is None:
            return

        try:
            with open(resolved_file, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.rstrip('\n')
                    
                    # Field splitting
                    if field_separator == r'\s+':
                        fields = line.split()
                    elif field_separator == ',':
                        fields = line.split(',')
                    else:
                        fields = re.split(field_separator, line)
                    
                    # Simple AWK script processing
                    if script == '{print}' or script == '{print $0}':
                        print(line)
                    elif script.startswith('{print $'):
                        # Extract field number
                        field_match = re.search(r'\$(\d+)', script)
                        if field_match:
                            field_num = int(field_match.group(1))
                            if field_num == 0:
                                print(line)
                            elif 1 <= field_num <= len(fields):
                                print(fields[field_num - 1].strip())
                    elif script.startswith('{print $1'):
                        # Print multiple fields
                        field_matches = re.findall(r'\$(\d+)', script)
                        output_fields = []
                        for field_str in field_matches:
                            field_num = int(field_str)
                            if field_num == 0:
                                output_fields.append(line)
                            elif 1 <= field_num <= len(fields):
                                output_fields.append(fields[field_num - 1].strip())
                        print(' '.join(output_fields))
                    elif '/' in script:
                        # Pattern matching
                        pattern_match = re.search(r'/([^/]+)/', script)
                        if pattern_match:
                            pattern = pattern_match.group(1)
                            if pattern in line:
                                if '{print}' in script or script.endswith('/'):
                                    print(line)
                    else:
                        # Basic pattern matching
                        if script in line:
                            print(line)
                        elif script == 'NR':
                            print(line_num)
                        elif script == 'NF':
                            print(len(fields))
        except PermissionError:
            print_error("awk", f"'{filename}': Permission denied")
        except Exception as e:
            print_error("awk", f"'{filename}': {str(e)}")
    except Exception as e:
        print_error("awk", f"unexpected error: {str(e)}")

def find_command(args_str):
    """find buyrug'i"""
    try:
        if not args_str:
            path_to_search = current_directory_path
            name_pattern = None
        else:
            args = parse_arguments(args_str)
            if args is None:
                return
            
            path_to_search = current_directory_path
            name_pattern = None
            
            # Parse arguments
            i = 0
            while i < len(args):
                if args[i] == '-name':
                    if i + 1 < len(args):
                        name_pattern = args[i + 1].strip('"\'')
                        # Convert wildcards to regex
                        name_pattern = name_pattern.replace('*', '.*').replace('?', '.')
                        i += 2
                    else:
                        print_error("find", "missing argument to '-name'")
                        return
                elif not args[i].startswith('-'):
                    path_to_search = safe_path_resolve(args[i], "find")
                    if path_to_search is None:
                        return
                    i += 1
                else:
                    i += 1

        if not path_to_search.startswith(REAL_OS_PATH):
            print_error("find", "Permission denied")
            return

        if not os.path.exists(path_to_search):
            print_error("find", "No such file or directory")
            return

        try:
            for root, dirs, files in os.walk(path_to_search):
                # Search in files
                for name in files:
                    if name_pattern:
                        if re.match(name_pattern + '$', name):
                            rel_path = os.path.relpath(os.path.join(root, name), REAL_OS_PATH)
                            print(f"~/{rel_path}")
                    else:
                        rel_path = os.path.relpath(os.path.join(root, name), REAL_OS_PATH)
                        print(f"~/{rel_path}")
                
                # Search in directories
                for name in dirs:
                    if name_pattern:
                        if re.match(name_pattern + '$', name):
                            rel_path = os.path.relpath(os.path.join(root, name), REAL_OS_PATH)
                            print(f"~/{rel_path}")
                    else:
                        rel_path = os.path.relpath(os.path.join(root, name), REAL_OS_PATH)
                        print(f"~/{rel_path}")
        except PermissionError:
            print_error("find", "Permission denied")
        except Exception as e:
            print_error("find", f"{str(e)}")
    except Exception as e:
        print_error("find", f"unexpected error: {str(e)}")

def wc_command(args_str):
    """wc buyrug'i"""
    try:
        if not validate_arguments("wc", args_str, min_args=1):
            return
        
        args = parse_arguments(args_str)
        if args is None:
            return
        
        show_lines = True
        show_words = True
        show_chars = True
        
        files = []
        for arg in args:
            if arg == '-l':
                show_lines = True
                show_words = False
                show_chars = False
            elif arg == '-w':
                show_lines = False
                show_words = True
                show_chars = False
            elif arg == '-c' or arg == '-m':
                show_lines = False
                show_words = False
                show_chars = True
            else:
                files.append(arg)
        
        if not files:
            print_missing_operand("wc")
            return
        
        for filename in files:
            resolved_file = safe_file_check(filename, "wc")
            if resolved_file is None:
                continue
            
            try:
                with open(resolved_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.count('\n')
                    words = len(content.split())
                    chars = len(content)
                    
                    output = []
                    if show_lines:
                        output.append(str(lines))
                    if show_words:
                        output.append(str(words))
                    if show_chars:
                        output.append(str(chars))
                    
                    print(f"{' '.join(output)} {filename}")
            except PermissionError:
                print_error("wc", f"'{filename}': Permission denied")
            except Exception as e:
                print_error("wc", f"'{filename}': {str(e)}")
    except Exception as e:
        print_error("wc", f"unexpected error: {str(e)}")

def sort_command(args_str):
    """sort buyrug'i"""
    try:
        if not validate_arguments("sort", args_str, min_args=1):
            return
        
        filename = args_str.strip()
        resolved_file = safe_file_check(filename, "sort")
        if resolved_file is None:
            return
        
        try:
            with open(resolved_file, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                sorted_lines = sorted(lines)
                for line in sorted_lines:
                    print(line.rstrip('\n'))
        except PermissionError:
            print_error("sort", f"'{filename}': Permission denied")
        except Exception as e:
            print_error("sort", f"'{filename}': {str(e)}")
    except Exception as e:
        print_error("sort", f"unexpected error: {str(e)}")

def tail_command(args_str):
    """tail buyrug'i"""
    try:
        if not validate_arguments("tail", args_str, min_args=1):
            return
        
        args = parse_arguments(args_str)
        if args is None:
            return
        
        num_lines = 10
        filename = None
        
        i = 0
        while i < len(args):
            if args[i] == '-n':
                if i + 1 < len(args):
                    try:
                        num_lines = int(args[i + 1])
                        i += 2
                    except ValueError:
                        print_error("tail", f"invalid number of lines: '{args[i + 1]}'")
                        return
                else:
                    print_error("tail", "option requires an argument -- 'n'")
                    return
            elif args[i].startswith('-n'):
                try:
                    num_lines = int(args[i][2:])
                    i += 1
                except ValueError:
                    print_error("tail", f"invalid number of lines: '{args[i][2:]}'")
                    return
            else:
                filename = args[i]
                break
        
        if filename is None:
            print_missing_operand("tail")
            return
        
        resolved_file = safe_file_check(filename, "tail")
        if resolved_file is None:
            return
        
        try:
            with open(resolved_file, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                for line in lines[-num_lines:]:
                    print(line.rstrip('\n'))
        except PermissionError:
            print_error("tail", f"'{filename}': Permission denied")
        except Exception as e:
            print_error("tail", f"'{filename}': {str(e)}")
    except Exception as e:
        print_error("tail", f"unexpected error: {str(e)}")

def head_command(args_str):
    """head buyrug'i"""
    try:
        if not validate_arguments("head", args_str, min_args=1):
            return
        
        args = parse_arguments(args_str)
        if args is None:
            return
        
        num_lines = 10
        filename = None
        
        i = 0
        while i < len(args):
            if args[i] == '-n':
                if i + 1 < len(args):
                    try:
                        num_lines = int(args[i + 1])
                        i += 2
                    except ValueError:
                        print_error("head", f"invalid number of lines: '{args[i + 1]}'")
                        return
                else:
                    print_error("head", "option requires an argument -- 'n'")
                    return
            elif args[i].startswith('-n'):
                try:
                    num_lines = int(args[i][2:])
                    i += 1
                except ValueError:
                    print_error("head", f"invalid number of lines: '{args[i][2:]}'")
                    return
            else:
                filename = args[i]
                break
        
        if filename is None:
            print_missing_operand("head")
            return
        
        resolved_file = safe_file_check(filename, "head")
        if resolved_file is None:
            return
        
        try:
            with open(resolved_file, 'r', encoding='utf-8', errors='ignore') as f:
                for i, line in enumerate(f):
                    if i >= num_lines:
                        break
                    print(line.rstrip('\n'))
        except PermissionError:
            print_error("head", f"'{filename}': Permission denied")
        except Exception as e:
            print_error("head", f"'{filename}': {str(e)}")
    except Exception as e:
        print_error("head", f"unexpected error: {str(e)}")

def help_command(args_str=None):
    """help buyrug'i"""
    try:
        print("Little Red CTF Shell - Available Commands:")
        commands = sorted([cmd for cmd in COMMAND_MAP.keys() if cmd != 'exit'])
        
        max_len = max(len(cmd) for cmd in commands) + 4
        try:
            terminal_width = os.get_terminal_size().columns
        except OSError:
            terminal_width = 80

        cols = max(1, terminal_width // max_len)
        
        for i, command in enumerate(commands):
            print(f"{command:<{max_len}}", end="")
            if (i + 1) % cols == 0:
                print()
        print("\n\nFor more information, use 'man <command>'.")
    except Exception as e:
        print_error("help", f"unexpected error: {str(e)}")

def clear_command(args_str=None):
    """clear buyrug'i"""
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
    except Exception as e:
        print_error("clear", f"unexpected error: {str(e)}")

def man_command(args_str):
    """man buyrug'i"""
    try:
        if not args_str:
            print("What manual page do you want?")
            return
        
        command_name = args_str.strip()
        
        # Basic man pages
        man_pages = {
            "ls": "List directory contents",
            "cd": "Change directory",
            "cat": "Display file contents",
            "grep": "Search patterns in files",
            "awk": "Pattern scanning and processing",
            "find": "Search for files and directories",
            "wc": "Word, line, character, and byte count",
            "sort": "Sort lines of text",
            "head": "Output first part of files",
            "tail": "Output last part of files",
            "echo": "Display line of text",
            "mkdir": "Create directories",
            "touch": "Create empty files or update timestamps",
            "help": "Show available commands",
            "clear": "Clear terminal screen",
            "history": "Show command history",
            "alias": "Create command aliases",
            "env": "Display environment variables",
            "which": "Locate command",
            "nano": "Text editor",
            "chmod": "Change file permissions",
            "chown": "Change file ownership",
            "watch": "Execute commands periodically"
        }
        
        if command_name in man_pages:
            print(f"{command_name.upper()}(1)")
            print(f"NAME\n       {command_name} - {man_pages[command_name]}")
            print(f"\nSYNOPSIS\n       {command_name} [options] [arguments]")
            print(f"\nDESCRIPTION\n       {man_pages[command_name]}")
        else:
            print(f"No manual entry for {command_name}")
    except Exception as e:
        print_error("man", f"unexpected error: {str(e)}")

def ps_command(args_str=None):
    """ps buyrug'i simulatsiyasi"""
    try:
        print("  PID TTY          TIME CMD")
        print(" 1234 pts/0    00:00:01 bash")
        print(" 5678 pts/0    00:00:00 ctf-terminal")
    except Exception as e:
        print_error("ps", f"unexpected error: {str(e)}")

def kill_command(args_str):
    """kill buyrug'i simulatsiyasi"""
    try:
        if not args_str:
            print_missing_operand("kill")
            return
        print(f"kill: simulated command - would kill process {args_str}")
    except Exception as e:
        print_error("kill", f"unexpected error: {str(e)}")

def alias_command(args_str):
    """alias buyrug'i"""
    try:
        global ALIASES
        if not args_str:
            # Show all aliases
            for key, value in ALIASES.items():
                print(f"alias {key}='{value}'")
            return

        if '=' not in args_str:
            # Show specific alias
            if args_str in ALIASES:
                print(f"alias {args_str}='{ALIASES[args_str]}'")
            else:
                print_error("alias", f"{args_str}: not found")
            return

        # Create new alias
        try:
            key, value = args_str.split('=', 1)
            value = value.strip().strip("'\"")
            ALIASES[key.strip()] = value
        except ValueError:
            print_error("alias", "invalid syntax")
    except Exception as e:
        print_error("alias", f"unexpected error: {str(e)}")

def history_command(args_str=None):
    """history buyrug'i"""
    try:
        if not COMMAND_HISTORY:
            return
        
        for i, cmd in enumerate(COMMAND_HISTORY):
            print(f" {i+1}  {cmd}")
    except Exception as e:
        print_error("history", f"unexpected error: {str(e)}")

def env_command(args_str=None):
    """env buyrug'i"""
    try:
        print(f"USER={USER_NAME}")
        print(f"HOME={REAL_OS_PATH}")
        print(f"PWD={current_directory_path}")
        print("PATH=/usr/local/bin:/usr/bin:/bin")
        print("TERM=xterm-256color")
        print("SHELL=/bin/bash")
    except Exception as e:
        print_error("env", f"unexpected error: {str(e)}")

def which_command(program_name):
    """which buyrug'i"""
    try:
        if not program_name:
            print_missing_operand("which")
            return
        
        if program_name in COMMAND_MAP:
            print(f"/usr/bin/{program_name}")
        elif program_name in ALIASES:
            print(f"alias {program_name}='{ALIASES[program_name]}'")
        else:
            return  # No output like real which
    except Exception as e:
        print_error("which", f"unexpected error: {str(e)}")

def nano_command(args_str):
    """nano editor - to'liq ishlaydigan versiya"""
    try:
        if not args_str:
            print_missing_operand("nano")
            return
        
        filename = args_str.strip()
        full_path = os.path.join(current_directory_path, filename)
        
        # OS folder ichida ekanligini tekshirish
        if not full_path.startswith(REAL_OS_PATH):
            print_error("nano", f"'{filename}': Permission denied")
            return
        
        # Fayl mavjudligini tekshirish va yaratish
        file_exists = os.path.exists(full_path)
        if not file_exists:
            # Yangi fayl yaratish
            try:
                with open(full_path, 'w', encoding='utf-8') as f:
                    f.write("")
            except PermissionError:
                print_error("nano", f"'{filename}': Permission denied")
                return
            except Exception as e:
                print_error("nano", f"'{filename}': {str(e)}")
                return
        
        # Faylni o'qish
        try:
            with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except PermissionError:
            print_error("nano", f"'{filename}': Permission denied")
            return
        except Exception as e:
            print_error("nano", f"'{filename}': {str(e)}")
            return
        
        # Nano editor interfeysi
        print(f"{COLOR_HACKING_CYAN}GNU nano 6.2{COLOR_RESET}                    {filename}")
        print()
        
        lines = content.splitlines() if content else [""]
        cursor_line = 0
        cursor_col = 0
        modified = False
        
        def display_content():
            """Fayl mazmunini ko'rsatish"""
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"{COLOR_HACKING_CYAN}GNU nano 6.2{COLOR_RESET}                    {filename}")
            print()
            
            # Faylning birinchi 20 qatorini ko'rsatish
            display_lines = lines[:20] if len(lines) > 20 else lines
            for i, line in enumerate(display_lines):
                if i == cursor_line:
                    # Cursor qatorini highlight qilish
                    if cursor_col < len(line):
                        before_cursor = line[:cursor_col]
                        cursor_char = line[cursor_col] if cursor_col < len(line) else ' '
                        after_cursor = line[cursor_col + 1:]
                        print(f"{before_cursor}{COLOR_HACKING_BOLD}{cursor_char}{COLOR_RESET}{after_cursor}")
                    else:
                        print(f"{line}{COLOR_HACKING_BOLD} {COLOR_RESET}")
                else:
                    print(line)
            
            # Bo'sh qatorlar qo'shish (agar kerak bo'lsa)
            for i in range(len(display_lines), 20):
                print()
            
            # Status bar
            status = f"Modified" if modified else f"New File" if not file_exists else ""
            print(f"\n{COLOR_HACKING_BOLD}[ {status} ]{COLOR_RESET}")
            
            # Help bar
            print(f"{COLOR_HACKING_YELLOW}^G Get Help  ^O Write Out ^R Read File ^Y Prev Page ^K Cut Text  ^C Cur Pos{COLOR_RESET}")
            print(f"{COLOR_HACKING_YELLOW}^X Exit      ^J Justify   ^W Where Is  ^V Next Page ^U Paste     ^T To Spell{COLOR_RESET}")
        
        def save_file():
            """Faylni saqlash"""
            nonlocal modified
            try:
                with open(full_path, 'w', encoding='utf-8') as f:
                    f.write('\n'.join(lines))
                modified = False
                return True
            except Exception as e:
                print(f"Error writing file: {e}")
                return False
        
        def get_input():
            """Foydalanuvchi kiritishini olish"""
            try:
                return input().strip()
            except (KeyboardInterrupt, EOFError):
                return None
        
        # Nano editor asosiy tsikli
        while True:
            display_content()
            
            print(f"\nCurrent position: Line {cursor_line + 1}, Col {cursor_col + 1}")
            print("Commands: 'i' (insert), 'a' (append), 'd' (delete line), 's' (save), 'q' (quit)")
            print("Enter command or text to insert:")
            
            user_input = get_input()
            if user_input is None:
                continue
            
            if user_input == 'q':
                # Quit
                if modified:
                    print("Save modified buffer? (y/n)")
                    save_choice = get_input()
                    if save_choice and save_choice.lower() == 'y':
                        if save_file():
                            print(f"File '{filename}' saved.")
                        else:
                            print("Error saving file!")
                            continue
                break
            
            elif user_input == 's':
                # Save
                if save_file():
                    print(f"File '{filename}' saved.")
                    input("Press Enter to continue...")
                else:
                    print("Error saving file!")
                    input("Press Enter to continue...")
            
            elif user_input == 'i':
                # Insert mode
                print("Insert mode - Enter text (empty line to exit):")
                while True:
                    text = get_input()
                    if text is None or text == "":
                        break
                    
                    # Insert text at cursor position
                    if cursor_line >= len(lines):
                        lines.extend([""] * (cursor_line - len(lines) + 1))
                    
                    current_line = lines[cursor_line]
                    lines[cursor_line] = current_line[:cursor_col] + text + current_line[cursor_col:]
                    cursor_col += len(text)
                    modified = True
            
            elif user_input == 'a':
                # Append mode
                print("Append mode - Enter text (empty line to exit):")
                while True:
                    text = get_input()
                    if text is None or text == "":
                        break
                    
                    lines.append(text)
                    cursor_line = len(lines) - 1
                    cursor_col = len(text)
                    modified = True
            
            elif user_input == 'd':
                # Delete current line
                if cursor_line < len(lines):
                    lines.pop(cursor_line)
                    if cursor_line >= len(lines) and len(lines) > 0:
                        cursor_line = len(lines) - 1
                    cursor_col = 0
                    modified = True
            
            elif user_input.startswith('g '):
                # Go to line
                try:
                    line_num = int(user_input[2:]) - 1
                    if 0 <= line_num < len(lines):
                        cursor_line = line_num
                        cursor_col = 0
                    else:
                        print(f"Line {line_num + 1} not found")
                        input("Press Enter to continue...")
                except ValueError:
                    print("Invalid line number")
                    input("Press Enter to continue...")
            
            elif user_input.startswith('f '):
                # Find text
                search_text = user_input[2:]
                found = False
                for i, line in enumerate(lines[cursor_line:], cursor_line):
                    if search_text in line:
                        cursor_line = i
                        cursor_col = line.find(search_text)
                        found = True
                        break
                
                if not found:
                    print(f"'{search_text}' not found")
                    input("Press Enter to continue...")
            
            elif user_input == 'h':
                # Help
                print("\nNano Editor Help:")
                print("i - Insert mode")
                print("a - Append mode")
                print("d - Delete current line")
                print("s - Save file")
                print("q - Quit")
                print("g <line> - Go to line number")
                print("f <text> - Find text")
                print("h - Show this help")
                input("\nPress Enter to continue...")
            
            else:
                # Direct text input
                if cursor_line >= len(lines):
                    lines.extend([""] * (cursor_line - len(lines) + 1))
                
                current_line = lines[cursor_line]
                lines[cursor_line] = current_line[:cursor_col] + user_input + current_line[cursor_col:]
                cursor_col += len(user_input)
                modified = True
        
        # Clear screen after exiting
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"Exited nano editor")
    except Exception as e:
        print_error("nano", f"unexpected error: {str(e)}")

def bash_command(args_str):
    """bash buyrug'i - shell script ishga tushirish"""
    try:
        if not args_str:
            print_missing_operand("bash")
            return
        
        script_file = args_str.strip()
        resolved_file = safe_file_check(script_file, "bash")
        if resolved_file is None:
            return
        
        execute_shell_script(resolved_file)
    except Exception as e:
        print_error("bash", f"unexpected error: {str(e)}")

def sh_command(args_str):
    """sh buyrug'i - shell script ishga tushirish"""
    try:
        if not args_str:
            print_missing_operand("sh")
            return
        
        script_file = args_str.strip()
        resolved_file = safe_file_check(script_file, "sh")
        if resolved_file is None:
            return
        
        execute_shell_script(resolved_file)
    except Exception as e:
        print_error("sh", f"unexpected error: {str(e)}")

def execute_shell_script(script_path):
    """Shell scriptni bajarish"""
    try:
        with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        
        print(f"Executing shell script: {os.path.basename(script_path)}")
        
        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            
            # Bo'sh qatorlar va izohlarni o'tkazib yuborish
            if not line or line.startswith('#'):
                continue
            
            # Shebang qatorini o'tkazib yuborish
            if line.startswith('#!/'):
                continue
            
            print(f"[{line_num}] {line}")
            
            # Buyruqni bajarish
            if '|' in line:
                # Pipeline buyruqlar
                pipe_commands_str = line.split('|')
                piped_commands = []
                for cmd_part in pipe_commands_str:
                    cmd_part = cmd_part.strip()
                    if not cmd_part:
                        continue
                    parts = cmd_part.split(" ", 1)
                    cmd = parts[0]
                    cmd_args = parts[1] if len(parts) > 1 else ""
                    piped_commands.append((cmd, cmd_args))
                
                if piped_commands:
                    execute_piped_commands(piped_commands)
            else:
                # Oddiy buyruq
                parts = line.split(" ", 1)
                command = parts[0]
                args = parts[1] if len(parts) > 1 else ""
                
                # Script ichida exit bo'lsa, scriptni to'xtatish
                if command == "exit":
                    print("Script execution completed with exit.")
                    break
                
                execute_command(command, args, from_source=True)
    
    except PermissionError:
        print_error("bash", f"'{script_path}': Permission denied")
    except Exception as e:
        print_error("bash", f"Error executing script: {str(e)}")

def execute_executable_file(file_path):
    """Executable faylni ishga tushirish"""
    try:
        # .sh fayllar uchun
        if file_path.endswith('.sh'):
            execute_shell_script(file_path)
            return True
        
        # Python fayllar uchun
        if file_path.endswith('.py'):
            print(f"python: executing {os.path.basename(file_path)}")
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                # Python kodni bajarish xavfli, shuning uchun faqat ko'rsatamiz
                print("Python script content:")
                print(content)
            except Exception as e:
                print_error("python", f"Error reading script: {str(e)}")
            return True
        
        return False
    except Exception as e:
        print_error("execute", f"unexpected error: {str(e)}")
        return False

# Pipeline support
def execute_piped_commands(commands_list):
    """Pipeline buyruqlarini bajarish"""
    try:
        input_data = ""
        
        for i, (cmd, args) in enumerate(commands_list):
            if cmd == "cat" and i == 0:
                # First command in pipeline
                resolved_file = safe_file_check(args, "cat")
                if resolved_file is None:
                    return
                
                try:
                    with open(resolved_file, 'r', encoding='utf-8', errors='ignore') as f:
                        input_data = f.read()
                except Exception as e:
                    print_error("cat", f"{str(e)}")
                    return
            
            elif cmd == "grep" and input_data:
                # Grep from piped input
                pattern = args
                output_lines = []
                for line in input_data.splitlines():
                    if pattern in line:
                        output_lines.append(line)
                input_data = "\n".join(output_lines)
            
            elif cmd == "sort" and input_data:
                # Sort piped input
                lines = sorted(input_data.splitlines())
                input_data = "\n".join(lines)
            
            elif cmd == "head" and input_data:
                # Head from piped input
                lines = input_data.splitlines()
                num_lines = 10
                if args.startswith('-n'):
                    try:
                        num_lines = int(args[2:])
                    except ValueError:
                        num_lines = 10
                input_data = "\n".join(lines[:num_lines])
            
            elif cmd == "tail" and input_data:
                # Tail from piped input
                lines = input_data.splitlines()
                num_lines = 10
                if args.startswith('-n'):
                    try:
                        num_lines = int(args[2:])
                    except ValueError:
                        num_lines = 10
                input_data = "\n".join(lines[-num_lines:])
            
            elif cmd == "wc" and input_data:
                # Word count from piped input
                lines = input_data.count('\n')
                words = len(input_data.split())
                chars = len(input_data)
                
                if args == '-l':
                    print(lines)
                elif args == '-w':
                    print(words)
                elif args == '-c' or args == '-m':
                    print(chars)
                else:
                    print(f"{lines} {words} {chars}")
                return
            
            else:
                print_error("pipeline", f"Command '{cmd}' not supported in pipeline")
                return
        
        # Print final output
        if input_data:
            print(input_data)
    except Exception as e:
        print_error("pipeline", f"unexpected error: {str(e)}")

# Command mapping
COMMAND_MAP = {
    "ls": safe_command_wrapper(ls_command),
    "cd": safe_command_wrapper(cd_command),
    "cat": safe_command_wrapper(cat_command),
    "mkdir": safe_command_wrapper(mkdir_command),
    "touch": safe_command_wrapper(touch_command),
    "echo": safe_command_wrapper(echo_command),
    "chmod": safe_command_wrapper(chmod_command),
    "chown": safe_command_wrapper(chown_command),
    "watch": safe_command_wrapper(watch_command),
    "grep": safe_command_wrapper(grep_command),
    "awk": safe_command_wrapper(awk_command),
    "find": safe_command_wrapper(find_command),
    "wc": safe_command_wrapper(wc_command),
    "sort": safe_command_wrapper(sort_command),
    "tail": safe_command_wrapper(tail_command),
    "head": safe_command_wrapper(head_command),
    "help": safe_command_wrapper(help_command),
    "clear": safe_command_wrapper(clear_command),
    "man": safe_command_wrapper(man_command),
    "ps": safe_command_wrapper(ps_command),
    "kill": safe_command_wrapper(kill_command),
    "alias": safe_command_wrapper(alias_command),
    "history": safe_command_wrapper(history_command),
    "env": safe_command_wrapper(env_command),
    "which": safe_command_wrapper(which_command),
    "nano": safe_command_wrapper(nano_command),
    "bash": safe_command_wrapper(bash_command),
    "sh": safe_command_wrapper(sh_command),
    "ll": safe_command_wrapper(lambda args: ls_command("-la " + (args or ""))),
    "la": safe_command_wrapper(lambda args: ls_command("-a " + (args or ""))),
    "l": safe_command_wrapper(lambda args: ls_command("-l " + (args or ""))),
}

def execute_command(command, args, from_source=False):
    """Buyruqni xavfsiz bajarish"""
    try:
        # ./script.sh formatini tekshirish
        if command.startswith('./'):
            script_path = command[2:]  # ./ ni olib tashlash
            resolved_file = safe_path_resolve(script_path, command)
            
            if resolved_file is None:
                return
            
            if not resolved_file.startswith(REAL_OS_PATH):
                print_error(command, "Permission denied")
                return
            
            if not os.path.exists(resolved_file):
                print_error(command, "No such file or directory")
                return
            
            if os.path.isdir(resolved_file):
                print_error(command, "Is a directory")
                return
            
            # Executable faylni ishga tushirish
            if execute_executable_file(resolved_file):
                return
            else:
                print_error(command, "Permission denied or unsupported file type")
                return
        
        # Check aliases
        if command in ALIASES:
            try:
                full_alias_cmd = ALIASES[command]
                alias_cmd_parts = full_alias_cmd.split(' ', 1)
                actual_command = alias_cmd_parts[0]
                actual_args = alias_cmd_parts[1] + " " + args if len(alias_cmd_parts) > 1 else args
                
                if actual_command == command:
                    print_error(command, "alias creates an infinite loop")
                    return

                command = actual_command
                args = actual_args
            except Exception as e:
                print_error("alias", f"error processing alias: {str(e)}")
                return

        # Handle exit
        if command == "exit":
            if not from_source:
                print("Exiting terminal.")
                sys.exit(0)
            else:
                print("exit: Command ignored in sourced file.")
                return
        
        # Execute command
        if command in COMMAND_MAP:
            try:
                if args:
                    COMMAND_MAP[command](args)
                else:
                    COMMAND_MAP[command]()
            except TypeError:
                # Command doesn't take arguments
                try:
                    COMMAND_MAP[command]()
                except Exception as e:
                    print_error(command, f"execution error: {str(e)}")
            except Exception as e:
                print_error(command, f"execution error: {str(e)}")
        else:
            print_command_not_found(command)
    
    except Exception as e:
        print_error("system", f"unexpected error executing '{command}': {str(e)}")

def setup_environment():
    """Muhitni xavfsiz sozlash"""
    try:
        if not os.path.exists(REAL_OS_PATH):
            print(f"Creating OS directory structure...")
            os.makedirs(REAL_OS_PATH)
            
            # Create directory structure
            dirs = [
                "home/user",
                "etc",
                "var/log",
                "tmp",
                "challenge"
            ]
            
            for dir_path in dirs:
                os.makedirs(os.path.join(REAL_OS_PATH, dir_path), exist_ok=True)
            
            # Create sample files
            files = {
                "etc/motd.txt": "Welcome to the CTF terminal simulator!\n",
                "home/user/profile.txt": "User profile information\n",
                "home/user/test.txt": "Line 1\nLine 2\nLine 3\n",
                "challenge/flag.txt": "CTF_FLAG{welcome_to_the_simulation}\n",
                "challenge/data.txt": "apple\nbanana\ncherry\napple\ndate\n",
                "challenge/data.csv": "name,age,city,salary\nJohn,25,NYC,50000\nJane,30,LA,60000\nBob,35,Chicago,55000\n",
                "home/user/test_script.sh": "#!/bin/bash\necho 'Hello from shell script!'\nls -la\necho 'Script completed'\n",
                "home/user/virus.sh": "#!/bin/bash\necho 'Simulated virus script'\necho 'Scanning system...'\necho 'No threats found'\n"
            }
            
            for file_path, content in files.items():
                full_path = os.path.join(REAL_OS_PATH, file_path)
                with open(full_path, 'w') as f:
                    f.write(content)
            
            print("Environment setup complete!")
        elif not os.path.isdir(REAL_OS_PATH):
            print(f"Error: '{REAL_OS_PATH}' exists but is not a directory.")
            sys.exit(1)
        
        # Load permissions
        safe_load_permissions()
        
    except Exception as e:
        print(f"Error setting up environment: {str(e)}")
        print("Continuing with limited functionality...")

def run_ctf_terminal():
    """Asosiy terminal tsikli - hech qachon to'xtamaydi"""
    ascii_logo = rf"""
{COLOR_HACKING_CYAN}▖  ▖  ▜     {COLOR_RESET}{COLOR_HACKING_RED}       ▗     ▄    ▌▄▖    {COLOR_RESET}
{COLOR_HACKING_CYAN}▌▞▖▌█▌▐ ▛▘▛▌▛▛▌█▌  {COLOR_RESET}{COLOR_HACKING_RED}▜▘▛▌  ▌▌█▌▛▌▚ █▌▛▘{COLOR_RESET}
{COLOR_HACKING_CYAN}▛ ▝▌▙▖▐▖▙▖▙▌▌▌▌▙▖  {COLOR_RESET}{COLOR_HACKING_RED}▐▖▙▌  ▙▘▙▖▙▌▄▌▙▖▙▖{COLOR_RESET} {COLOR_HACKING_GREEN}{COLOR_HACKING_BOLD}Little Red{COLOR_RESET}

{COLOR_HACKING_YELLOW}{COLOR_HACKING_BOLD}remember they're listening!!!{COLOR_RESET}
"""
    print(ascii_logo)
    print(f"{COLOR_HACKING_YELLOW}Type 'help' for available commands.{COLOR_RESET}")
    print(f"{COLOR_HACKING_GREEN}This terminal is error-safe and will never crash!{COLOR_RESET}")
    
    while True:
        try:
            display_path = get_display_path_string()
            prompt = f"{COLOR_PROMPT_USER_HOST}{USER_NAME}@{HOST_NAME}{COLOR_RESET}:{COLOR_PROMPT_PATH}{display_path}{COLOR_RESET}$ "
            
            try:
                user_input = input(prompt).strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n{COLOR_HACKING_YELLOW}Use 'exit' to quit.{COLOR_RESET}")
                continue
            
            if not user_input:
                continue

            # Add to history
            try:
                COMMAND_HISTORY.append(user_input)
            except Exception:
                pass  # History xatosi dasturni to'xtatmaslik kerak
            
            # Parse and execute command
            try:
                parts = user_input.split(" ", 1)
                command = parts[0]
                args = parts[1] if len(parts) > 1 else ""

                safe_execute(execute_command, command, args)
            except Exception as e:
                print_error("system", f"command parsing error: {str(e)}")
                continue
        
        except Exception as e:
            print_error("system", f"terminal error: {str(e)}")
            print(f"{COLOR_HACKING_GREEN}Terminal recovered and ready for next command.{COLOR_RESET}")
            continue

def main():
    """Asosiy funksiya - xavfsiz"""
    try:
        setup_environment()
        run_ctf_terminal()
    except Exception as e:
        print(f"{COLOR_ERROR}Fatal error: {str(e)}{COLOR_RESET}")
        print(f"{COLOR_HACKING_YELLOW}Attempting to recover...{COLOR_RESET}")
        try:
            run_ctf_terminal()
        except Exception:
            print(f"{COLOR_ERROR}Could not recover. Exiting...{COLOR_RESET}")
            sys.exit(1)

if __name__ == "__main__":
    main()
